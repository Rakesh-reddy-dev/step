from solution import attendanceSummary

assert attendanceSummary([1, 1, 0, 1, 1, 1, 0, 1]) == (6, 3)
assert attendanceSummary([0, 0, 0]) == (0, 0)
assert attendanceSummary([1, 1, 1]) == (3, 3)
assert attendanceSummary([1]) == (1, 1)
assert attendanceSummary([0]) == (0, 0)
print("All tests passed")
