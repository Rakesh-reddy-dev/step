import random
from solution import countInBand

S = [35, 42, 42, 50, 58, 58, 58, 63, 71, 88]
assert countInBand(S, 42, 58) == 6
assert countInBand(S, 90, 100) == 0
assert countInBand([50], 50, 50) == 1
assert countInBand([50], 0, 49) == 0
for _ in range(2000):
    a = sorted(random.randint(0, 100) for _ in range(random.randint(1, 50)))
    lo = random.randint(0, 100); hi = random.randint(lo, 100)
    assert countInBand(a, lo, hi) == sum(lo <= x <= hi for x in a)
print("All tests passed")
