# Problem 6: Class Attendance Tracker

Run: `python solution.py` and `python test_solution.py`

## Approach
One pass. Each `1` increments `present` and the running `streak` (updating
`longest` if the streak is a new maximum); each `0` resets `streak` to 0.

## Complexity
- Time: O(n)
- Space: O(1)

## Single pass?
Yes. The total present days and the longest streak are both updated in the same
loop, so no second traversal is needed.
