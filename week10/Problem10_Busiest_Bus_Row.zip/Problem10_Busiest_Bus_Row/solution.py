def busiestRow(grid):
    best_row = 0
    best_total = -1
    for i, row in enumerate(grid):
        total = 0
        for seat in row:
            total += seat
        if total > best_total:      # strictly larger -> ties keep smaller index
            best_total = total
            best_row = i
    return best_row, best_total


if __name__ == "__main__":
    grid = [[2, 0, 1],
            [3, 3, 1],
            [1, 1, 1]]
    r, t = busiestRow(grid)
    print(f"Row {r}, Total {t}")   # Row 1, Total 7
