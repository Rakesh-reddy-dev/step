# Problem 7: Second-Best Score

Run: `python solution.py` and `python test_solution.py`

## Approach
Track `highest` and `second` (both start at -1, which is below any valid score).
For each score: if it beats `highest`, the old highest becomes `second`; else if
it is different from `highest` and beats `second`, it becomes `second`.
Scores equal to `highest` are skipped, so duplicates never become `second`.

## Complexity
| Method | Time | Space |
|---|---|---|
| Two-variable scan (final) | O(n) | O(1) |
| Sort first, then find 2nd distinct | O(n log n) | O(1) in-place / O(n) if copied |

The scan visits each element once and is faster than sorting, which does extra
work ordering elements we do not need. The task also forbids sorting.
