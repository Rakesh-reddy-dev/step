def attendanceSummary(days):
    present = 0
    streak = 0
    longest = 0
    for d in days:
        if d == 1:
            present += 1
            streak += 1
            if streak > longest:
                longest = streak
        else:
            streak = 0
    return present, longest


if __name__ == "__main__":
    for days in ([1, 1, 0, 1, 1, 1, 0, 1], [0, 0, 0]):
        p, l = attendanceSummary(days)
        print(f"Present: {p}, Longest streak: {l}")
