def secondHighest(scores):
    highest = -1
    second = -1
    for s in scores:
        if s > highest:
            second = highest
            highest = s
        elif s != highest and s > second:
            second = s
    return second          # stays -1 if no distinct second score exists


if __name__ == "__main__":
    print(secondHighest([45, 78, 92, 78, 60]))  # 78
    print(secondHighest([50, 50, 50]))          # -1
