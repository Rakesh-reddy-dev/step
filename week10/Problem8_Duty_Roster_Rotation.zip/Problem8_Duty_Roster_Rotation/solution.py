def rotateRoster(names, k):
    n = len(names)
    k %= n                       # remove full turns
    result = [None] * n
    for i, name in enumerate(names):
        result[(i + k) % n] = name
    return result


if __name__ == "__main__":
    print(rotateRoster(["A", "B", "C", "D", "E"], 2))  # [D, E, A, B, C]
    print(rotateRoster(["A", "B", "C", "D", "E"], 7))  # [D, E, A, B, C]
