def first_ge(scores, target):
    """Index of the first element >= target (len(scores) if none)."""
    lo, hi = 0, len(scores)
    while lo < hi:
        mid = (lo + hi) // 2
        if scores[mid] >= target:
            hi = mid          # keep searching left: duplicates may exist
        else:
            lo = mid + 1
    return lo


def first_gt(scores, target):
    """Index of the first element > target (len(scores) if none)."""
    lo, hi = 0, len(scores)
    while lo < hi:
        mid = (lo + hi) // 2
        if scores[mid] > target:
            hi = mid
        else:
            lo = mid + 1
    return lo


def countInBand(scores, low, high):
    return first_gt(scores, high) - first_ge(scores, low)


if __name__ == "__main__":
    s = [35, 42, 42, 50, 58, 58, 58, 63, 71, 88]
    print(countInBand(s, 42, 58))   # 6
    print(countInBand(s, 90, 100))  # 0
