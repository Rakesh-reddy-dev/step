import random
from solution import secondHighest

assert secondHighest([45, 78, 92, 78, 60]) == 78
assert secondHighest([50, 50, 50]) == -1
assert secondHighest([7]) == -1
assert secondHighest([0, 100]) == 0
assert secondHighest([100, 100, 99]) == 99
assert secondHighest([0, 0, 0]) == -1
for _ in range(2000):
    a = [random.randint(0, 100) for _ in range(random.randint(1, 30))]
    u = sorted(set(a))
    assert secondHighest(a) == (u[-2] if len(u) > 1 else -1)
print("All tests passed")
