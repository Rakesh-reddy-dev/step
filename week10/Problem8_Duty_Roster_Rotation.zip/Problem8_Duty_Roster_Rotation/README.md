# Problem 8: Duty Roster Rotation

Run: `python solution.py` and `python test_solution.py`

## Approach
Reduce `k` with `k % n` (full turns change nothing), then place the name at
index `i` into index `(i + k) % n` of a new list.

## Complexity
- Time: O(n)
- Space: O(n) for the output list (O(1) extra with the three-reversal trick)

## Why rotating one place at a time is slow
Each single-step rotation costs O(n), so doing it k times costs O(n * k).
With k up to 10^9 that is up to ~10^11 operations. Most of that work is wasted
because every n steps the roster returns to its original order. Using `k % n`
caps the effective shift below n, making the whole job O(n).
