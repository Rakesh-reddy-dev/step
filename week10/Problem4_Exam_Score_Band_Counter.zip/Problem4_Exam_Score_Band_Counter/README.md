# Problem 4: Exam Score Band Counter

Run: `python solution.py` and `python test_solution.py`

## Approach
Because the array is sorted, the count of scores in [low, high] is
`first index with score > high` minus `first index with score >= low`.
Both are found with a modified binary search.

## Complexity
| Method | Time | Space |
|---|---|---|
| Linear scan | O(n) per query | O(1) |
| Binary search (final) | O(log n) per query | O(1) |

With n = 10^6, a scan does up to 1,000,000 steps per query; binary search does ~20.

## Duplicates at the band edges
A standard binary search stops at *any* matching element, which could be the
middle of a run of equal scores (e.g. one of three 58s), giving a wrong boundary.
So the search must not stop on a match: on `scores[mid] >= low` (or `> high`) it
keeps moving `hi = mid` to push left until the *first* qualifying position is
found. Using `>= low` for the lower edge includes every duplicate of `low`, and
`> high` for the upper edge includes every duplicate of `high`.
