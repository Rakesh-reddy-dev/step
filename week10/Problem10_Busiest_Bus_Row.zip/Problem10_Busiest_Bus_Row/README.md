# Problem 10: Busiest Bus Row

Run: `python solution.py` and `python test_solution.py`

## Approach
Outer loop over rows, inner loop sums each row. Update the best row only when
the new total is strictly greater, so ties keep the smaller index.

## Complexity
- Time: O(r * c)
- Additional space: O(1) (only a few integer variables)
