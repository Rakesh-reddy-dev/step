from solution import busiestRow

assert busiestRow([[2, 0, 1], [3, 3, 1], [1, 1, 1]]) == (1, 7)
assert busiestRow([[1, 2], [2, 1]]) == (0, 3)          # tie -> smaller index
assert busiestRow([[0]]) == (0, 0)
assert busiestRow([[0, 0], [0, 0]]) == (0, 0)
assert busiestRow([[1], [3], [2]]) == (1, 3)
print("All tests passed")
