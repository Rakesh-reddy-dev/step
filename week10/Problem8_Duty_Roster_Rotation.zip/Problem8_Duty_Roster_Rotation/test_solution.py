from solution import rotateRoster

R = ["A", "B", "C", "D", "E"]
assert rotateRoster(R, 2) == ["D", "E", "A", "B", "C"]
assert rotateRoster(R, 7) == ["D", "E", "A", "B", "C"]
assert rotateRoster(R, 0) == R
assert rotateRoster(R, 5) == R
assert rotateRoster(R, 10**9) == R
assert rotateRoster(["X"], 10**9) == ["X"]
assert R == ["A", "B", "C", "D", "E"]   # input not mutated
print("All tests passed")
